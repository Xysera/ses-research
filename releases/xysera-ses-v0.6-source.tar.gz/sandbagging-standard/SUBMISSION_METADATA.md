# Submission metadata

## Title

Toward an Evidence Standard for Sandbagging Claims: A Literature Synthesis, Reference Implementation and Worked Application

## Current author/byline

Xysera Research

Confirm the final personal or group author list before upload.

## Abstract

“Sandbagging,” strategic underperformance on an evaluation, matters because capability evaluations inform deployment and governance decisions. The literature offers many ways to induce, detect and remove it, but our search did not identify a single operational standard that says what behavioural evidence is required before a result may be called sandbagging, or how strongly. We synthesise more than 40 sources into a Sandbagging Evidence Standard with five cumulative claim levels and criteria for capability, artifact exclusion, consequence dependence, strategic signature, reasoning, elicitation, internal evidence and evaluation awareness. A reference implementation computes matched-cell criteria from trial-level logs. We exercise it with eight tests on simulated logs, a worked application to 166,250 trials from a preregistered study of five small open-weight models, and a sensitivity analysis. On the real data, a matched neutral note reproduces the apparent penalty-note degradation, yielding the label L1-ctx rather than consequence-sensitive underperformance. Near-threshold labels were sensitive to the equivalence margin and small subsamples. The standard is a proposal, not a validated measurement instrument: it has been exercised only on induced cases, nulls and artifacts, supports claims about behaviour rather than intent, and has not yet undergone independent review.

## Keywords

AI safety; language models; sandbagging; strategic underperformance; capability evaluation; evaluation integrity; evaluation awareness; capability elicitation

## Suggested subject areas

- Artificial Intelligence (cs.AI)
- Computation and Language (cs.CL)
- Machine Learning (cs.LG), if a secondary category is appropriate

## Public-facing summary

This paper proposes a reproducible standard for grading evidence of language-model sandbagging. Its worked application shows why ordinary prompt-context effects must be ruled out before an accuracy drop is attributed to consequences or strategic underperformance.

## Upload set

1. `xysera-ses-v0.5-paper.pdf`
2. `xysera-ses-v0.5-source.tar.gz`
3. `xysera-ses-v0.5-data.tar.gz`
4. `DATA_MANIFEST_v0.5.txt`
5. `RELEASE_SHA256SUMS.txt`

Before upload, complete the unchecked publisher actions in `PUBLICATION_CHECKLIST.md`.
