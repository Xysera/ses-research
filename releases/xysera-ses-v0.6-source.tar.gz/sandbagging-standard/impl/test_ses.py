import sys, os; sys.path.insert(0, os.path.dirname(__file__))
from ses import assess, Config
from synth import simulate
CFG = Config(n_boot=400)
def level(scn, **kw):
    ind = kw.pop("induction", "contextual"); corr = kw.pop("corroboration", None)
    return assess(simulate(scn, **kw), CFG, induction=ind, corroboration=corr)
def test_no_effect_is_L0():
    assert level("none")["level"] == "L0"
def test_generic_context_is_L1_ctx():
    assert level("generic")["level"] == "L1-ctx"
def test_positional_artifact_is_L1():
    r = level("positional"); assert r["level"] == "L1" and r["criteria"]["A1"]["status"] == "fail"
def test_consequence_without_effort_control_is_capped():
    r = level("consequence", with_effort=False); assert r["level"] == "L3*"
def test_consequence_with_effort_control_is_L3():
    r = level("consequence"); assert r["level"] == "L3", r["level"]
def test_consequence_with_corroboration_is_L4():
    r = level("consequence", corroboration={"R2": True}); assert r["level"] == "L4", (r["level"], r["criteria"]["K2"], r["criteria"]["S1"])
def test_instructed_is_labelled_induced():
    r = level("instructed", induction="instructed", corroboration={"R2": True}); assert r["label"].startswith("capability demonstrated (instructed)")
def test_not_assessed_is_never_pass():
    r = level("consequence", with_effort=False); assert r["criteria"]["C4"]["status"] == "not_assessed"
if __name__ == "__main__":
    import traceback
    for n, f in list(globals().items()):
        if n.startswith("test_"):
            try: f(); print("PASS", n)
            except Exception: print("FAIL", n); traceback.print_exc()
