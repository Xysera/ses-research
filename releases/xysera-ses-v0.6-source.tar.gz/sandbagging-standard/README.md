# Sandbagging Evidence Standard (SES) v0.5 release candidate

A specification, reference implementation and worked example for deciding how strongly a model-evaluation result can be described as sandbagging, without new model runs.

- `sources/LEDGER.md`: sources used, what was actually read, quantities and limits.
- `criteria/STANDARD.md`: claim levels L0-L4, criteria K/A/C/S/R/E/I/W, decision table, reporting checklist.
- `impl/ses.py`: reference implementation (matched-cell two-way cluster bootstrap, equivalence, letter-distribution test, recovery, verdict). `impl/synth.py`: synthetic logs with known ground truth. `impl/test_ses.py`: 8 tests.
- `examples/`: Study 1 worked example.
- `sources/SEARCH_PROTOCOL.md`, `examples/SENSITIVITY_REPORT.md`, `CHANGELOG.md`.

## Run
```
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python impl/test_ses.py
```
See `REPRODUCE.md` for the worked example and full-data layout.

## Log schema (DataFrame columns)
item_id, template, role (baseline|penalty|mirror|third_party|neutral|reward|effort_control), correct (0/1), response_letter, correct_letter; optional severity, source, domain (target|control). Cells (item_id, template) must be matched across roles (same option permutation).

## Status and limits
Release candidate v0.5. Validated only against synthetic cases, Study 1 null/artifact cases, induced cases, and a small negative exploratory screen. Thresholds marked provisional are conventions. The standard supports claims of behaviour only, never intent. Not peer reviewed. See `paper/CITATION_AUDIT.md` for the publication claim audit.
