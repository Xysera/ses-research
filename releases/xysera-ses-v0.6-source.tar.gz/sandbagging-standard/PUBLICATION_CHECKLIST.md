# Publication handoff checklist

## Ready

- [x] Claim and citation audit completed.
- [x] Evidence language distinguishes underperformance from motive or intent.
- [x] Portable Python environment documented and clean-environment tests passed (8/8).
- [x] Hard-coded local paths removed from the worked-example scripts.
- [x] Manuscript tightened and research-transparency disclosures added.
- [x] Publication PDF rendered and visually inspected page by page.
- [x] Citation metadata and data-availability statement prepared.
- [x] Raw-data inclusions and the unused partial run identified.

## Publisher actions

- [ ] Confirm the public author/byline. The release candidate currently uses the group author “Xysera Research”.
- [ ] Select and add licenses. Recommended default: CC BY 4.0 for the paper/documentation/data and Apache-2.0 or MIT for code.
- [ ] Choose the permanent repository URL and add it to `CITATION.cff`.
- [ ] Upload the five complete confirmatory logs and three exploratory-screen logs as supplementary artifacts.
- [ ] Upload the manuscript PDF and source package to the selected preprint/archive service.
- [ ] Add the assigned DOI or preprint identifier to `CITATION.cff`, README and manuscript.
- [ ] Preserve v0.5 unchanged after release; make later corrections as a new version.

## Recommended public description

We propose a reproducible evidence standard for grading sandbagging claims. A worked application shows why generic prompt-context effects must be separated from consequence-sensitive underperformance. The standard is a research proposal, not a validated universal detector, and it makes no claims about model intent.
