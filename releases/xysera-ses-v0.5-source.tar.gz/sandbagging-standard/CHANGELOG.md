# Changelog
## v0.1 (2026-10-23)
- Initial draft from ledger S1-S16 and Study 1.
- Implementation decisions made after looking at example data (provisional, flag for review):
  1. A5 is not assessed when A3 fails (found when the synthetic generic-context case was mis-labelled L1 instead of L1-ctx).
  2. A1 fails only if the letter-distribution shift is both significant (p<0.01) and practically large (JS>=0.05). The first version failed on significance alone, which flagged Qwen3-4B's instructed case (p=0.0004, JS=0.009) with ~250k trials.
  3. C3 returns not_assessed when severity does not vary.
- Thresholds a1_p, a1_js and a5_sign_share are provisional conventions, not calibrated on independent data.

## v0.2 (2026-10-23)
- Added criteria S3b (content engagement / difficulty profile, S22, S23) and S4 (cross-context consistency, S24), both report-only; added to `impl/ses.py`.
- Added the "elicitation is not detection" rule (S6, S21), probe format-control requirement (S25, S26), awareness-framing record (S27), capability-vs-propensity section (S17, S28, S29), and minimum-data guidance from the sensitivity analysis.
- Ledger v0.2: 19 new sources (S17-S35) from the arXiv listing and web search; reading depth recorded per source; Kimi K2.5 and auditing-games details verified against full text on disk.
- `contrast` results are cached by content hash (performance only; no change to results).
- Added `sources/SEARCH_PROTOCOL.md` and `examples/SENSITIVITY_REPORT.md`.
- Rerun of tests: 8/8 pass.

## v0.3 (2026-10-23)
- Closed arXiv paging gaps; added 7 abstract-level sources (S36-S42) and listing-only candidates (S43).
- Read full text of S2 (App. B.6), S3 (App. M.1), S24 (C3) and verified numbers; ledger details section added.
- Standard: C2 prior-art note (S3, S2); C4 evidence on instruction controls (weak single-sentence control); S2 threshold calibration evidence; no-CoT caveat (S2 B.6.3); adversarial-hiding limits (S36, S40, S39); detection-reporting rule (Recall@5% FPR, reference-set size, identity control); log retention and assumption declaration (S37, S38).
- Correction to Study 1 manuscript related work (prior consequence controls exist for frontier models).

## v0.4 (2026-10-23)
- Full-text verification of S21, S22, S23, S25, S36, S40 (ledger section); S15 (Anthropic system cards) and the OpenAI blog confirmed unobtainable with available tools and kept out of evidence.
- S3b nuance from S22 (entropy and content engagement are partially independent) and S23 detection rates added; Study 1 S3b worked example added.

## v0.4+ (2026-10-24)
- Added exploratory screen 2 (three open reasoning models, 324 prompts, thinking on, emphasis ladder with matched controls): no accuracy effect and no stated intent to underperform; Qwen3-8B referred to the strongest deletion note in 5/12 traces. Reported in `examples/SCREEN2_REPORT.md` and paper Section 5(iii). Not used to change any criterion.

## v0.5 release candidate (2026-10-24)
- Completed the publication claim and citation audit (`paper/CITATION_AUDIT.md`).
- Replaced “spontaneous sandbagging” wording with the narrower “underperformance without an explicit instruction” where models were placed in constructed consequence scenarios.
- Bounded the novelty statement to what the documented search identified.
- Removed quantitative statements supported only by abstract-level readings.
- Corrected the bibliography by separating two Cacioli papers and completing the Boxo et al. author list.
- Reconciled package-facing version labels.
